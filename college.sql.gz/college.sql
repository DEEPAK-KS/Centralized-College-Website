-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2023 at 03:16 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college`
--

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE `batch` (
  `BatchID` int(11) NOT NULL,
  `BatchName` varchar(255) DEFAULT NULL,
  `StartDate` int(5) DEFAULT NULL,
  `EndDate` int(5) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `DeptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`BatchID`, `BatchName`, `StartDate`, `EndDate`, `CourseID`, `DeptID`) VALUES
(1, 'INTMCA26', 2021, 2026, 110, 1010),
(2, 'CIVIl25', 2021, 2025, 102, 1002),
(3, 'CHEMICAL25', 2021, 2025, 101, 1001),
(4, 'COMPUTER25', 2021, 2025, 103, 1003),
(5, 'MCA24', 2022, 2024, 111, 1010);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `CourseID` int(11) NOT NULL,
  `CourseName` varchar(255) DEFAULT NULL,
  `DeptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`CourseID`, `CourseName`, `DeptID`) VALUES
(101, 'CHEMICAL', 1001),
(102, 'CIVIL', 1002),
(103, 'COMPUTER', 1003),
(104, 'FOOD TECHNOLOGY', 1004),
(105, 'ELECTRONIC & COMMUNICATION ENGINEERING', 1005),
(106, 'ELECTRICAL & ELECTRONICS ENGINEERING', 1006),
(107, 'INFORMATION TECHNOLOGY', 1007),
(108, 'MECHANICAL ENGINEERING (AUTOMOBILE)', 1008),
(109, 'METALLURGICAL & MATERIALS ENGINEERING', 1009),
(110, 'INTEGRATED MCA (5 YEARS)', 1010),
(111, 'REGULAR MCA (2 YEARS)', 1010);

-- --------------------------------------------------------

--
-- Table structure for table `credential`
--

CREATE TABLE `credential` (
  `user` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `credential`
--

INSERT INTO `credential` (`user`, `password`) VALUES
('deepak', 'deepak123'),
('rony', 'rony12345');

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `DeptID` int(11) NOT NULL,
  `DepartmentName` varchar(255) DEFAULT NULL,
  `HeadOfDepartment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`DeptID`, `DepartmentName`, `HeadOfDepartment`) VALUES
(1001, 'CHEMICAL', 'Emily Thompson'),
(1002, 'CIVIL', 'Jacob Martinez'),
(1003, 'COMPUTER', 'Olivia Davis'),
(1004, 'FOOD TECHNOLOGY', 'Ethan Rodriguez'),
(1005, 'ELECTRONIC & COMMUNICATION ENGINEERING', 'Sophia Turner'),
(1006, 'ELECTRICAL & ELECTRONICS ENGINEERING', 'Logan Patel'),
(1007, 'INFORMATION TECHNOLOGY', 'Mia Chang'),
(1008, 'MECHANICAL ENGINEERING (AUTOMOBILE)', 'Ava Johnson'),
(1009, 'METALLURGICAL & MATERIALS ENGINEERING', 'Lucas Williams'),
(1010, 'MCA', 'Sophia Johnson'),
(1011, 'HUMANITIES', 'Daniel Smith'),
(1012, 'BASIC SCIENCE', 'Emma Wilson');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `EventID` int(11) NOT NULL,
  `EventName` varchar(255) DEFAULT NULL,
  `EventDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `ExamID` int(11) NOT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `ExamDate` date DEFAULT NULL,
  `ExamName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `FctlyID` int(11) NOT NULL,
  `FacultyName` varchar(255) DEFAULT NULL,
  `Specialization` varchar(255) DEFAULT NULL,
  `DeptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`FctlyID`, `FacultyName`, `Specialization`, `DeptID`) VALUES
(1, 'John Doe', 'Computer Science and Engineering', 1001),
(2, 'Jane Smith', 'Electrical Engineering', 1002),
(3, 'Bob Johnson', 'Mechanical Engineering', 1003),
(4, 'Alice Brown', 'Civil Engineering', 1004),
(5, 'Charlie Davis', 'Chemical Engineering', 1005),
(6, 'Eva Wilson', 'Aerospace Engineering', 1006),
(7, 'David Miller', 'Materials Science and Engineering', 1007),
(8, 'Sophia Taylor', 'Biomedical Engineering', 1008),
(9, 'William Anderson', 'Environmental Engineering', 1009),
(10, 'Olivia Moore', 'Industrial Engineering', 1010),
(11, 'James White', 'Computer Science and Engineering', 1011),
(12, 'Emma Hall', 'Electrical Engineering', 1012),
(13, 'Michael Lee', 'Mechanical Engineering', 1001),
(14, 'Laura Adams', 'Civil Engineering', 1002),
(15, 'Brian Clark', 'Chemical Engineering', 1003),
(16, 'Zoe Evans', 'Aerospace Engineering', 1004),
(17, 'Aaron Harris', 'Materials Science and Engineering', 1005),
(18, 'Grace Allen', 'Biomedical Engineering', 1006),
(19, 'Daniel Turner', 'Environmental Engineering', 1007),
(20, 'Isabella Ward', 'Industrial Engineering', 1008),
(21, 'Joseph Hill', 'Computer Science and Engineering', 1009),
(22, 'Ava Scott', 'Electrical Engineering', 1010),
(23, 'Christopher Reed', 'Mechanical Engineering', 1011),
(24, 'Mia Parker', 'Civil Engineering', 1012),
(25, 'John Smith', 'Chemical Engineering', 1001),
(26, 'Emily Johnson', 'Aerospace Engineering', 1002),
(27, 'Robert Brown', 'Materials Science and Engineering', 1003),
(28, 'Jennifer Davis', 'Biomedical Engineering', 1004),
(29, 'Michael Wilson', 'Environmental Engineering', 1005),
(30, 'Jessica Miller', 'Industrial Engineering', 1006),
(31, 'Brian Taylor', 'Computer Science and Engineering', 1007),
(32, 'Hannah Anderson', 'Electrical Engineering', 1008),
(33, 'David Moore', 'Mechanical Engineering', 1009),
(34, 'Sophie White', 'Civil Engineering', 1010),
(35, 'Richard Hall', 'Chemical Engineering', 1011),
(36, 'Laura Lee', 'Aerospace Engineering', 1012),
(37, 'Matthew Adams', 'Materials Science and Engineering', 1001),
(38, 'Olivia Clark', 'Biomedical Engineering', 1002),
(39, 'Christopher Evans', 'Environmental Engineering', 1003),
(40, 'Natalie Harris', 'Industrial Engineering', 1004),
(41, 'Ethan Allen', 'Computer Science and Engineering', 1005),
(42, 'Emma Turner', 'Electrical Engineering', 1006),
(43, 'Jacob Ward', 'Mechanical Engineering', 1007),
(44, 'Madison Hill', 'Civil Engineering', 1008),
(45, 'Ella Scott', 'Chemical Engineering', 1009),
(46, 'Aiden Reed', 'Aerospace Engineering', 1010),
(47, 'Grace Parker', 'Materials Science and Engineering', 1011),
(48, 'Leo Brown', 'Biomedical Engineering', 1012),
(49, 'Hazel Adams', 'Environmental Engineering', 1001),
(50, 'Jackson Clark', 'Industrial Engineering', 1002),
(51, 'Scarlett Evans', 'Computer Science and Engineering', 1003),
(52, 'Lucas Harris', 'Electrical Engineering', 1004),
(53, 'Lily Allen', 'Mechanical Engineering', 1005),
(54, 'Elijah Turner', 'Civil Engineering', 1006),
(55, 'Chloe Ward', 'Chemical Engineering', 1007),
(56, 'Grayson Hill', 'Aerospace Engineering', 1008),
(57, 'Zoe Scott', 'Materials Science and Engineering', 1009),
(58, 'Ezra Reed', 'Biomedical Engineering', 1010),
(59, 'Penelope Parker', 'Environmental Engineering', 1011),
(60, 'Sawyer Brown', 'Industrial Engineering', 1012),
(61, 'Aria Lee', 'Computer Science and Engineering', 1001),
(62, 'Jackson Adams', 'Electrical Engineering', 1002),
(63, 'Scarlett Clark', 'Mechanical Engineering', 1003),
(64, 'Lucas Evans', 'Civil Engineering', 1004),
(65, 'Lily Harris', 'Chemical Engineering', 1005),
(66, 'Elijah Turner', 'Aerospace Engineering', 1006),
(67, 'Chloe Ward', 'Materials Science and Engineering', 1007),
(68, 'Grayson Hill', 'Biomedical Engineering', 1008),
(69, 'Zoe Scott', 'Environmental Engineering', 1009),
(70, 'Ezra Reed', 'Industrial Engineering', 1010),
(71, 'Penelope Parker', 'Computer Science and Engineering', 1011),
(72, 'Sawyer Brown', 'Electrical Engineering', 1012),
(73, 'Aria Lee', 'Mechanical Engineering', 1001),
(74, 'Jackson Adams', 'Civil Engineering', 1002),
(75, 'Scarlett Clark', 'Chemical Engineering', 1003),
(76, 'Lucas Evans', 'Aerospace Engineering', 1004),
(77, 'Lily Harris', 'Materials Science and Engineering', 1005),
(78, 'Elijah Turner', 'Biomedical Engineering', 1006),
(79, 'Chloe Ward', 'Environmental Engineering', 1007),
(80, 'Grayson Hill', 'Industrial Engineering', 1008),
(81, 'Zoe Scott', 'Computer Science and Engineering', 1009),
(82, 'Ezra Reed', 'Electrical Engineering', 1010),
(83, 'Penelope Parker', 'Mechanical Engineering', 1011),
(84, 'Sawyer Brown', 'Civil Engineering', 1012),
(85, 'Aria Lee', 'Chemical Engineering', 1001),
(86, 'Jackson Adams', 'Aerospace Engineering', 1002),
(87, 'Scarlett Clark', 'Materials Science and Engineering', 1003),
(88, 'Lucas Evans', 'Biomedical Engineering', 1004),
(89, 'Lily Harris', 'Environmental Engineering', 1005),
(90, 'Elijah Turner', 'Industrial Engineering', 1006),
(91, 'Chloe Ward', 'Computer Science and Engineering', 1007),
(92, 'Grayson Hill', 'Electrical Engineering', 1008),
(93, 'Zoe Scott', 'Mechanical Engineering', 1009),
(94, 'Ezra Reed', 'Civil Engineering', 1010),
(95, 'Penelope Parker', 'Chemical Engineering', 1011),
(96, 'Sawyer Brown', 'Aerospace Engineering', 1012),
(97, 'Aria Lee', 'Materials Science and Engineering', 1001),
(98, 'Jackson Adams', 'Biomedical Engineering', 1002),
(99, 'Scarlett Clark', 'Environmental Engineering', 1003),
(100, 'Lucas Evans', 'Industrial Engineering', 1004);

-- --------------------------------------------------------

--
-- Table structure for table `librarybook`
--

CREATE TABLE `librarybook` (
  `BookID` int(11) NOT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Author` varchar(255) DEFAULT NULL,
  `DeptID` int(11) DEFAULT NULL,
  `AvailabilityStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `nonteachingstaff`
--

CREATE TABLE `nonteachingstaff` (
  `EmployeeID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Position` varchar(255) DEFAULT NULL,
  `ContactNumber` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nonteachingstaff`
--

INSERT INTO `nonteachingstaff` (`EmployeeID`, `Name`, `Position`, `ContactNumber`) VALUES
(1, 'John Doe', 'Administrative', '555-123-4567'),
(2, 'Jane Smith', 'IT Support', '555-234-5678'),
(3, 'Robert Johnson', 'Facilities', '555-345-6789'),
(4, 'Emily Davis', 'Finance', '555-456-7890'),
(5, 'Michael Brown', 'Maintenance', '555-567-8901'),
(6, 'Sophia Miller', 'HR', '555-678-9012'),
(7, 'David Wilson', 'IT Support', '555-789-0123'),
(8, 'Olivia Taylor', 'Facilities', '555-890-1234'),
(9, 'Daniel Lee', 'Finance', '555-901-2345'),
(10, 'Emma Anderson', 'Maintenance', '555-012-3456'),
(11, 'James Martinez', 'Administrative', '555-123-4567'),
(12, 'Ava Thomas', 'IT Support', '555-234-5678'),
(13, 'William Brown', 'Facilities', '555-345-6789'),
(14, 'Lily Garcia', 'Finance', '555-456-7890'),
(15, 'Ethan Robinson', 'Maintenance', '555-567-8901'),
(16, 'Isabella Harris', 'HR', '555-678-9012'),
(17, 'Benjamin Turner', 'IT Support', '555-789-0123'),
(18, 'Mia White', 'Facilities', '555-890-1234'),
(19, 'Logan Hall', 'Finance', '555-901-2345'),
(20, 'Avery King', 'Maintenance', '555-012-3456'),
(21, 'Sophie Adams', 'Administrative', '555-123-4567'),
(22, 'Jackson Scott', 'IT Support', '555-234-5678'),
(23, 'Amelia Baker', 'Facilities', '555-345-6789'),
(24, 'Lucas Green', 'Finance', '555-456-7890'),
(25, 'Ella Evans', 'Maintenance', '555-567-8901'),
(26, 'Grayson Garcia', 'HR', '555-678-9012'),
(27, 'Chloe Moore', 'IT Support', '555-789-0123'),
(28, 'Carter Johnson', 'Facilities', '555-890-1234'),
(29, 'Layla Harris', 'Finance', '555-901-2345'),
(30, 'Gabriel White', 'Maintenance', '555-012-3456'),
(31, 'Harper Wright', 'Administrative', '555-123-4567'),
(32, 'Lincoln Turner', 'IT Support', '555-234-5678'),
(33, 'Penelope Walker', 'Facilities', '555-345-6789'),
(34, 'Sebastian Reed', 'Finance', '555-456-7890'),
(35, 'Zoe Martinez', 'Maintenance', '555-567-8901'),
(36, 'Andrew Baker', 'HR', '555-678-9012'),
(37, 'Stella Clark', 'IT Support', '555-789-0123'),
(38, 'Leo Davis', 'Facilities', '555-890-1234'),
(39, 'Madison Adams', 'Finance', '555-901-2345'),
(40, 'Owen Hill', 'Maintenance', '555-012-3456');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `PlcmntID` int(11) NOT NULL,
  `BatchID` int(11) DEFAULT NULL,
  `DeptID` int(11) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `studName` varchar(255) DEFAULT NULL,
  `Company` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`PlcmntID`, `BatchID`, `DeptID`, `CourseID`, `studName`, `Company`) VALUES
(1, 1, 1010, 110, 'Divya', 'SutherLand');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`BatchID`),
  ADD KEY `CourseID` (`CourseID`),
  ADD KEY `DeptID` (`DeptID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`CourseID`),
  ADD KEY `DeptID` (`DeptID`);

--
-- Indexes for table `credential`
--
ALTER TABLE `credential`
  ADD PRIMARY KEY (`user`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`DeptID`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`EventID`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`ExamID`),
  ADD KEY `CourseID` (`CourseID`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`FctlyID`),
  ADD KEY `DepartmentID` (`DeptID`);

--
-- Indexes for table `librarybook`
--
ALTER TABLE `librarybook`
  ADD PRIMARY KEY (`BookID`),
  ADD KEY `DeptID` (`DeptID`);

--
-- Indexes for table `nonteachingstaff`
--
ALTER TABLE `nonteachingstaff`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`PlcmntID`),
  ADD KEY `BatchID` (`BatchID`),
  ADD KEY `DeptID` (`DeptID`),
  ADD KEY `CourseID` (`CourseID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `batch`
--
ALTER TABLE `batch`
  ADD CONSTRAINT `batch_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`),
  ADD CONSTRAINT `batch_ibfk_2` FOREIGN KEY (`DeptID`) REFERENCES `dept` (`DeptID`);

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`DeptID`) REFERENCES `dept` (`DeptID`);

--
-- Constraints for table `exam`
--
ALTER TABLE `exam`
  ADD CONSTRAINT `exam_ibfk_1` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`DeptID`) REFERENCES `dept` (`DeptID`);

--
-- Constraints for table `librarybook`
--
ALTER TABLE `librarybook`
  ADD CONSTRAINT `librarybook_ibfk_1` FOREIGN KEY (`DeptID`) REFERENCES `dept` (`DeptID`);

--
-- Constraints for table `placement`
--
ALTER TABLE `placement`
  ADD CONSTRAINT `placement_ibfk_1` FOREIGN KEY (`BatchID`) REFERENCES `batch` (`BatchID`),
  ADD CONSTRAINT `placement_ibfk_2` FOREIGN KEY (`DeptID`) REFERENCES `dept` (`DeptID`),
  ADD CONSTRAINT `placement_ibfk_3` FOREIGN KEY (`CourseID`) REFERENCES `course` (`CourseID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
